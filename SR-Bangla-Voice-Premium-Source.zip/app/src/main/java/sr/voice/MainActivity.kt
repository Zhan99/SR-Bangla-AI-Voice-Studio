package sr.voice

import android.app.*
import android.os.*
import android.content.*
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.text.TextWatcher
import android.text.Editable
import android.media.MediaPlayer
import android.widget.*
import android.view.View
import com.k2fsa.sherpa.onnx.*
import java.io.*
import java.util.zip.ZipInputStream
import java.text.Normalizer
import java.util.concurrent.Executors

class MainActivity : Activity() {
 private val worker = Executors.newSingleThreadExecutor()
 private lateinit var text: EditText
 private lateinit var status: TextView
 private lateinit var progress: ProgressBar
 private lateinit var voices: Spinner
 private lateinit var speed: SeekBar
 private lateinit var speaker: EditText
 private lateinit var generate: Button
 private lateinit var install: Button
 private lateinit var history: LinearLayout
 private var player: MediaPlayer? = null
 private var exportFile: File? = null
 @Volatile private var cancelled = false
 private var busy = false
 private val models get() = File(filesDir,"models").apply { mkdirs() }
 private val audio get() = File(filesDir,"audio").apply { mkdirs() }
 private val ink=0xffedf3ff.toInt()
 private val muted=0xffa8b6ce.toInt()
 private val accent=0xff76e4ce.toInt()
 private val panel=0xff18243b.toInt()
 private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
 private fun shape(c:Int,r:Int=18)=GradientDrawable().apply {setColor(c);cornerRadius=dp(r).toFloat()}
 private fun label(s:String)=TextView(this).apply {text=s;textSize=15f;setTextColor(ink);setPadding(0,dp(8),0,dp(6))}
 private fun button(s:String, action:()->Unit)=Button(this).apply {text=s;isAllCaps=false;setTextColor(ink);textSize=14f;background=shape(0xff293b57.toInt(),14);minHeight=dp(48);setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(7)}}
 private fun card(parent:LinearLayout):LinearLayout=LinearLayout(this).apply {orientation=1;background=shape(panel);setPadding(dp(16),dp(12),dp(16),dp(16));parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(14)})}
 private fun heading(s:String)=label(s).apply{textSize=19f;setTypeface(null,Typeface.BOLD)}
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor=0xff10192b.toInt();window.navigationBarColor=0xff10192b.toInt()
  val base=LinearLayout(this).apply{orientation=1;setBackgroundColor(0xff10192b.toInt());setPadding(dp(16),dp(12),dp(16),dp(8))}
  setContentView(base)
  base.addView(label("SR  /  CREATION FARM").apply{textSize=12f;setTextColor(accent);letterSpacing=0.12f})
  base.addView(heading("Bangla Voice Studio").apply{textSize=28f})
  base.addView(label("NEURAL AUDIO  •  OFFLINE STUDIO").apply{textSize=11f;setTextColor(muted)})
  val nav=LinearLayout(this).apply{orientation=0};base.addView(nav)
  val pages=FrameLayout(this);base.addView(pages,LinearLayout.LayoutParams(-1,0,1f))
  fun page():LinearLayout {val content=LinearLayout(this).apply{orientation=1;setPadding(0,dp(12),0,dp(12))};pages.addView(ScrollView(this).apply{isFillViewport=true;addView(content)},FrameLayout.LayoutParams(-1,-1));return content}
  val studio=page();val library=page();val recordings=page();val about=page()
  val tabs=listOf("Studio","Models","Audio","About")
  val tabButtons=mutableListOf<Button>()
  fun showPage(i:Int){for(j in tabs.indices){pages.getChildAt(j).visibility=if(i==j)View.VISIBLE else View.GONE;tabButtons[j].background=shape(if(i==j)0xff315b64.toInt() else panel,12);tabButtons[j].setTextColor(if(i==j)accent else muted)}}
  tabs.forEachIndexed{i,n->val b=button(n){showPage(i)};b.textSize=12f;b.setPadding(0,0,0,0);nav.addView(b,LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(4)});tabButtons.add(b)};showPage(0)
  val editor=card(studio);editor.addView(heading("01  লেখা লিখুন"));val count=label("০ অক্ষর").apply{setTextColor(muted);textSize=12f};editor.addView(count)
  text=EditText(this).apply {hint="বাংলা লেখা লিখুন বা পেস্ট করুন";setHintTextColor(muted);setTextColor(ink);textSize=18f;minLines=6;gravity=48;background=shape(0xff10192b.toInt(),12);setPadding(dp(12),dp(12),dp(12),dp(12));setText("বাংলাদেশ আমাদের প্রিয় মাতৃভূমি।")};editor.addView(text)
  count.text="${text.length()} অক্ষর"
  text.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,c:Int){count.text="${s?.length?:0} অক্ষর"};override fun afterTextChanged(e:Editable?){}})
  editor.addView(button("লেখা মুছুন"){text.text.clear()})
  val settings=card(studio);settings.addView(heading("02  Voice settings"));voices=Spinner(this);settings.addView(label("ইনস্টল করা AI মডেল"));settings.addView(voices)
  settings.addView(label("Speaker ID (মাল্টি-স্পিকার)"));speaker=EditText(this).apply{inputType=2;setTextColor(ink);setText("0")};settings.addView(speaker)
  val speedLabel=label("গতি: 1.0x");settings.addView(speedLabel)
  speed=SeekBar(this).apply{max=100;progress=50;progressTintList=ColorStateList.valueOf(accent);thumbTintList=ColorStateList.valueOf(accent);setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(b:SeekBar,p:Int,u:Boolean){speedLabel.text="গতি: ${0.5f+p/100f}x"};override fun onStartTrackingTouch(b:SeekBar){};override fun onStopTrackingTouch(b:SeekBar){}})};settings.addView(speed)
  val render=card(studio);render.addView(heading("03  Generate audio"));generate=button("✦  AI ভয়েস তৈরি করুন"){synthesize()}.apply{background=shape(accent);setTextColor(0xff102a32.toInt());setTypeface(null,Typeface.BOLD)};render.addView(generate);render.addView(button("বাতিল করুন"){cancelled=true});progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progressTintList=ColorStateList.valueOf(accent)};render.addView(progress);status=label("প্রস্তুত");render.addView(status)
  val mc=card(library);mc.addView(heading("AI Model Library"));mc.addView(label("৩৮টি মডেল ও চেকপয়েন্ট • কেবল সামঞ্জস্যপূর্ণ VITS মডেল চালানো যায়").apply{setTextColor(muted)});install=button("＋ VITS মডেল ZIP ইনস্টল"){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},10)};mc.addView(install)
  assets.open("catalog.txt").bufferedReader().useLines{lines->lines.filter{it.contains("|")}.forEach{line->val row=line.split('|');val c=card(library);c.addView(heading(row[0]));c.addView(label(row[2]).apply{setTextColor(if(row[2].startsWith("Default"))accent else muted);textSize=13f});c.addView(button("মডেল তথ্য / উৎস"){browse(row[1])})}}
  recordings.addView(heading("Audio collection"));history=LinearLayout(this).apply{orientation=1};recordings.addView(history)
  val info=card(about);info.addView(heading("SR Creation Farm"));info.addView(label("Developer: Shahriar Rahman\nOffline Neural Voice Studio\nPremium interface"));info.addView(button("YouTube"){browse("https://www.youtube.com/@SRCreation-farm")});info.addView(button("Facebook"){browse("https://fb.com/srcreation.farm")})
  refresh(); refreshHistory(); if (!File(models,"Bangla VITS").exists()) {
   setBusy(true); worker.execute { try { val d=File(models,"Bangla VITS"); d.mkdirs(); for(n in listOf("model.onnx","tokens.txt")) assets.open("default/$n").use { i->File(d,n).outputStream().use { i.copyTo(it) } }; ui { status.text="অফলাইন মডেল প্রস্তুত"; refresh() } } catch(e:Exception){File(models,"Bangla VITS").deleteRecursively(); ui { status.text="মডেল কপি ব্যর্থ: ${e.message}" }} finally {ui {setBusy(false)}} }
  }
 }
 private fun ui(f:()->Unit) { runOnUiThread { if(!isDestroyed) f() } }
 private fun setBusy(v:Boolean){ busy=v; generate.isEnabled=!v; install.isEnabled=!v }
 private fun refresh(){ voices.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,models.listFiles()?.filter{File(it,"model.onnx").isFile && File(it,"tokens.txt").isFile}?.map{it.name}?.sorted()?:emptyList<String>()) }
 private fun browse(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(e:Exception){status.text=e.message}}
 private fun catalog(){ val entries=assets.open("catalog.txt").bufferedReader().readLines().filter{it.contains("|")}; AlertDialog.Builder(this).setTitle("মডেল ক্যাটালগ — রূপান্তর/লাইসেন্স যাচাই প্রয়োজন").setItems(entries.map{it.substringBefore('|')}.toTypedArray()){_,i-> val row=entries[i].split('|'); AlertDialog.Builder(this).setTitle(row[0]).setMessage(row[2]+"\n\nশুধু Sherpa-compatible VITS ZIP সরাসরি ইনস্টল করা যাবে।").setPositiveButton("মডেল পেজ"){_,_->browse(row[1])}.setNegativeButton("বন্ধ",null).show() }.show() }
 private fun chunks(s:String):List<String>{ val result=mutableListOf<String>(); val b=StringBuilder(); for(word in s.replace(Regex("([।!?])"),"$1 ").split(Regex("\\s+"))){if(word.isBlank())continue; if(b.length+word.length>220 && b.isNotEmpty()){result.add(b.toString().trim());b.clear()}; b.append(word).append(' '); if(word.last() in "।!?" ){result.add(b.toString().trim());b.clear()}};if(b.isNotBlank())result.add(b.toString().trim());return result }
 private fun synthesize(){ if(busy)return; val input=Normalizer.normalize(text.text.toString().trim(),Normalizer.Form.NFC); val name=voices.selectedItem?.toString(); if(input.isEmpty()||name==null){status.text="লেখা ও মডেল নির্বাচন করুন";return}; val parts=chunks(input); val rate=speed.progress/100f+0.5f; val sid=speaker.text.toString().toIntOrNull()?:0; cancelled=false; setBusy(true);progress.progress=0;status.text="মডেল লোড হচ্ছে…"
 worker.execute { var tts:OfflineTts?=null; val dest=File(audio,"Voice-${System.currentTimeMillis()}.wav"); try { val dir=File(models,name); val v=OfflineTtsVitsModelConfig(model=File(dir,"model.onnx").path,tokens=File(dir,"tokens.txt").path, dataDir=File(dir,"espeak-ng-data").takeIf{it.isDirectory}?.path?:"",lexicon=File(dir,"lexicon.txt").takeIf{it.isFile}?.path?:""); val engine=OfflineTts(assetManager=null,config=OfflineTtsConfig(model=OfflineTtsModelConfig(vits=v,numThreads=2),maxNumSentences=1)); tts=engine
 RandomAccessFile(dest,"rw").use { out->out.setLength(0);out.write(ByteArray(44));var hz=0;var bytes=0L;for((i,p) in parts.withIndex()){if(cancelled)throw InterruptedException("বাতিল");val a=engine.generate(p,sid,rate);require(a.samples.isNotEmpty()){ "খালি অডিও: অংশ ${i+1}" };if(hz==0)hz=a.sampleRate;require(hz==a.sampleRate);val data=ByteArray(a.samples.size*2);for(j in a.samples.indices){val x=(a.samples[j].coerceIn(-1f,1f)*32767).toInt();data[j*2]=x.toByte();data[j*2+1]=(x shr 8).toByte()};out.write(data);bytes+=data.size; val percent=(i+1)*100/parts.size;ui{progress.progress=percent;status.text="${percent}% • ${i+1}/${parts.size} অংশ"} };require(bytes>0 && bytes<2147483600);out.seek(0);out.writeBytes("RIFF");le(out,(bytes+36).toInt(),4);out.writeBytes("WAVEfmt ");le(out,16,4);le(out,1,2);le(out,1,2);le(out,hz,4);le(out,hz*2,4);le(out,2,2);le(out,16,2);out.writeBytes("data");le(out,bytes.toInt(),4) };ui{status.text="১০০% • অডিও তৈরি হয়েছে";refreshHistory()}
 }catch(e:Throwable){dest.delete();ui{status.text="ব্যর্থ: ${e.message}"}}finally{try{tts?.release()}finally{ui{setBusy(false)}}} }
 }
 private fun le(out:RandomAccessFile,v:Int,n:Int){repeat(n){out.write((v ushr (8*it)) and 255)}}
 private fun refreshHistory(){history.removeAllViews();audio.listFiles()?.sortedByDescending{it.name}?.forEach{f->val item=card(history);item.addView(label(f.name));item.addView(button("▶ শুনুন") {try{player?.release();player=MediaPlayer().apply{setDataSource(f.path);prepare();start()}}catch(e:Exception){status.text=e.message}});item.addView(button("WAV সেভ করুন"){exportFile=f;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="audio/wav";putExtra(Intent.EXTRA_TITLE,f.name)},11)});item.addView(button("ডিলিট"){player?.release();player=null;f.delete();refreshHistory()})}}
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==11){val f=exportFile?:return;try{contentResolver.openOutputStream(uri)?.use{ o->f.inputStream().use{it.copyTo(o)}};status.text="সেভ হয়েছে"}catch(e:Exception){status.text=e.message};return};if(requestCode!=10||busy)return;setBusy(true);worker.execute{val d=File(models,"Imported-${System.currentTimeMillis()}");d.mkdirs();try{var total=0L;ZipInputStream(contentResolver.openInputStream(uri)!!).use{z->while(true){val e=z.nextEntry?:break;val f=File(d,e.name);require(f.canonicalPath.startsWith(d.canonicalPath+File.separator));if(e.isDirectory)f.mkdirs() else {f.parentFile?.mkdirs();f.outputStream().use{o->val buf=ByteArray(65536);while(true){val n=z.read(buf);if(n<0)break;total+=n;require(total<1500L*1024*1024);o.write(buf,0,n)}}};z.closeEntry()}};require(File(d,"model.onnx").isFile&&File(d,"tokens.txt").isFile){"ZIP root-এ model.onnx ও tokens.txt প্রয়োজন"};ui{refresh();status.text="মডেল ইনস্টল হয়েছে (সংশ্লেষণের সময় যাচাই হবে)"}}catch(e:Exception){d.deleteRecursively();ui{status.text="ইনস্টল ব্যর্থ: ${e.message}"}}finally{ui{setBusy(false)}}}}
 override fun onDestroy(){cancelled=true;player?.release();worker.shutdown();super.onDestroy()}
}

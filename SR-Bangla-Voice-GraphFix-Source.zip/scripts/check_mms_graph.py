"""Repair missing ONNX interface type information for the documented MMS export.
Never change weights, node connections, or token IDs. Reject unknown interfaces.
"""
from pathlib import Path
import json
import onnx
from onnx import TensorProto, helper, shape_inference

PATH = Path('app/src/main/assets/bundled/Meta MMS Bengali/model.onnx')
REPORT = Path('mms-graph-report.json')
SIGNATURE = {
    'x': (TensorProto.INT64, ['N', 'L']),
    'x_length': (TensorProto.INT64, ['N']),
    'noise_scale': (TensorProto.FLOAT, [1]),
    'length_scale': (TensorProto.FLOAT, [1]),
    'noise_scale_w': (TensorProto.FLOAT, [1]),
    'y': (TensorProto.FLOAT, ['N', 1, 'T']),
}

def repair(model):
    graph = model.graph
    initializers = {v.name: v for v in graph.initializer}
    inputs = [v.name for v in graph.input if v.name not in initializers]
    outputs = [v.name for v in graph.output]
    if inputs != list(SIGNATURE)[:-1] or outputs != ['y']:
        raise ValueError(f'Unsupported MMS interface: {inputs} -> {outputs}')
    changes = []
    for v in list(graph.input) + list(graph.output):
        if v.name in initializers:
            t = initializers[v.name]
            dtype, dims = t.data_type, list(t.dims)
        else:
            dtype, dims = SIGNATURE[v.name]
        if not v.HasField('type') or not v.type.HasField('tensor_type') or not v.type.tensor_type.elem_type:
            v.type.CopyFrom(helper.make_tensor_type_proto(dtype, dims))
            changes.append(v.name + ': restored type')
        elif not v.type.tensor_type.HasField('shape'):
            if v.type.tensor_type.elem_type != dtype:
                raise ValueError(f'Unexpected dtype: {v.name}')
            v.type.CopyFrom(helper.make_tensor_type_proto(dtype, dims))
            changes.append(v.name + ': restored shape')
    # Intermediate annotations are optional. Remove only incomplete annotations,
    # not graph nodes, inputs, outputs, or initializers.
    for i in range(len(graph.value_info)-1, -1, -1):
        v = graph.value_info[i]
        if not v.HasField('type'):
            changes.append(v.name + ': removed incomplete optional annotation')
            del graph.value_info[i]
    if changes:
        model = shape_inference.infer_shapes(model, strict_mode=False)
    onnx.checker.check_model(model)
    metadata = {v.key:v.value for v in model.metadata_props}
    if metadata.get('model_type') != 'vits' or metadata.get('frontend') != 'characters' or int(metadata.get('sample_rate','0')) <= 0:
        raise ValueError(f'Invalid MMS metadata: {metadata}')
    return model, changes

def main():
    report = {}
    try:
        model, changes = repair(onnx.load(str(PATH)))
        tmp = PATH.with_suffix('.repair.onnx')
        onnx.save(model, str(tmp))
        onnx.checker.check_model(str(tmp))
        tmp.replace(PATH)
        report.update(status='passed', changes=changes)
    except Exception as e:
        report.update(status='failed', error=str(e))
        raise
    finally:
        REPORT.write_text(json.dumps(report, ensure_ascii=False, indent=2))
        print(report, flush=True)

if __name__ == '__main__':
    main()

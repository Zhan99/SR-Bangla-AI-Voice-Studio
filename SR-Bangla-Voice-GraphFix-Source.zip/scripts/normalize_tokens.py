"""Adapt character-only vocabularies without changing original model IDs."""
import pathlib, re, json, unicodedata
SPECIAL={"<PAD>","<EOS>","<BOS>","<BLNK>"}
SAMPLE="বাংলাদেশ আমাদের প্রিয় মাতৃভূমি।"
def normalize(raw):
    entries={}; skipped=[]; ids={}
    for i,line in enumerate(raw.split("\n"),1):
        line=line.rstrip("\r")
        if not line.strip(): continue
        m=re.fullmatch(r"(.*?)[ \t]+([0-9]+)[ \t]*",line)
        if m:
            token=m[1] or " "; idx=int(m[2])
        elif re.fullmatch(r"[0-9]+",line):
            token=" "; idx=int(line)
        else: raise ValueError(f"Invalid token row {i}: {line!r}")
        if token not in SPECIAL and len(token)!=1:
            skipped.append({"token":token,"id":idx}); continue
        if token in entries:
            if entries[token]!=idx: raise ValueError(f"Conflicting token IDs: {token!r}")
            continue
        entries[token]=idx
    if not entries: raise ValueError("Empty vocabulary")
    missing=sorted({c for c in unicodedata.normalize('NFC',SAMPLE) if '\u0980'<=c<='\u09ff' and unicodedata.category(c)[0] in 'LM' and c not in entries})
    if missing: raise ValueError(f"Bengali character coverage missing: {missing!r}; this model needs its own tokenizer")
    return ''.join(f'{t} {i}\n' for t,i in entries.items()),skipped

def main():
    base=pathlib.Path('app/src/main/assets/bundled'); report={}; failed=[]
    for p in sorted(base.iterdir()):
        if not p.is_dir():continue
        path=p/'tokens.txt'
        try:
            original=path.read_text(encoding='utf-8-sig'); new,skipped=normalize(original)
            path.write_text(new,encoding='utf-8');report[p.name]={'omitted_non_character_tokens':skipped}
            print(p.name, 'omitted non-character tokens:', len(skipped),flush=True)
        except Exception as e:
            report[p.name]={'error':str(e)};failed.append(p.name)
    pathlib.Path('token-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    if failed: raise SystemExit('Token validation failed: '+', '.join(failed))
if __name__=='__main__':main()

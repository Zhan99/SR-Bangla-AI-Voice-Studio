#!/usr/bin/env python3
"""Stage the 38 original catalog entries; never execute remote model code."""
import argparse, json, pathlib, shutil, subprocess, sys, os
from huggingface_hub import HfApi, snapshot_download
P=pathlib.Path
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='model-staging')
parser.add_argument('--embed',action='store_true')
parser.add_argument('--license-approval',action='store_true',help='Operator confirms redistribution rights for every entry')
parser.add_argument('--max-apk-assets',type=int,default=1500000000)
a=parser.parse_args()
rows=json.loads(P(__file__).with_name('models.json').read_text()); assert len(rows)==38 and len({r['id'] for r in rows})==38
root=P(a.output).resolve(); root.mkdir(parents=True,exist_ok=True)
api=HfApi(); report=[]
for r in rows:
 d=root/r['id']; d.mkdir(exist_ok=True); u=r['url']; item={**r,'status':'failed'}
 try:
  if 'huggingface.co/' in u:
   bits=u.split('huggingface.co/',1)[1].split('/'); repo='/'.join(bits[:2]); prefix='/'.join(bits[4:]) if len(bits)>4 and bits[2]=='tree' else ''
   info=api.model_info(repo,files_metadata=True); item['revision']=info.sha; item['license']=getattr(info.card_data,'license',None)
   files=[f for f in info.siblings if not prefix or f.rfilename.startswith(prefix+'/')]
   total=sum(f.size or 0 for f in files); item['estimated_bytes']=total
   if total+1024**3>shutil.disk_usage(root).free: raise RuntimeError('Insufficient free storage for snapshot')
   snapshot_download(repo_id=repo,revision=info.sha,local_dir=d,allow_patterns=[prefix+'/*'] if prefix else None)
   shutil.rmtree(d/'.cache',ignore_errors=True)
  else:
   subprocess.run(['git','clone','--depth','1',u,str(d/'repo')],check=True)
   subprocess.run(['git','-C',str(d/'repo'),'lfs','pull'],check=True)
   item['revision']=subprocess.check_output(['git','-C',str(d/'repo'),'rev-parse','HEAD'],text=True).strip(); shutil.rmtree(d/'repo'/'.git')
  weights=[p for p in d.rglob('*') if p.is_file() and p.suffix.lower() in {'.onnx','.pt','.pth','.bin','.safetensors','.ckpt','.gguf','.tflite','.nemo','.h5','.pb','.npz','.pkl'} and p.stat().st_size>100000]
  if not weights: raise RuntimeError('No recognizable model weights in repository; external checkpoint may be required')
  item['status']='staged'; item['bytes']=sum(p.stat().st_size for p in d.rglob('*') if p.is_file()); item['weight_files']=[str(p.relative_to(d)) for p in weights]
 except Exception as e: item['error']=str(e)
 report.append(item); (root/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,default=str)); print(r['id'],r['name'],item['status'],flush=True)
if any(x['status']!='staged' for x in report): sys.exit('Incomplete collection; see report.json')
if a.embed:
 if not a.license_approval: sys.exit('Embedding blocked: redistribution rights must be reviewed first')
 total=sum(x['bytes'] for x in report)
 if total>a.max_apk_assets: sys.exit(f'Embedding blocked: {total} bytes exceeds conservative APK asset budget {a.max_apk_assets}')
 dest=P('app/src/main/assets/raw-models'); shutil.copytree(root,dest,dirs_exist_ok=True)
 print('Raw weights embedded; separate Android inference adapters still required.')

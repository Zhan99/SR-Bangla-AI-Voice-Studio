import pathlib, math, sys, subprocess, json
base=pathlib.Path("app/src/main/assets/bundled")
expected=["Eleven-New","Merged News","SYSPIN Female","SYSPIN Male","Meta MMS Bengali"]
def check(name):
    import sherpa_onnx
    p=base/name
    config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(p/"model.onnx"),tokens=str(p/"tokens.txt")),num_threads=2))
    assert config.validate(), name
    tts=sherpa_onnx.OfflineTts(config)
    for sentence in ["বাংলাদেশ আমাদের প্রিয় মাতৃভূমি।", "আমি বাংলা ভাষায় কথা বলি।"]:
        if name=="Meta MMS Bengali":
            import re
            sentence=re.sub(r"[।॥!?.,;:…]", " ", sentence).strip()
        a=tts.generate(sentence,sid=0,speed=1.0)
        assert a.sample_rate>0 and len(a.samples)>a.sample_rate//4 and all(math.isfinite(x) for x in a.samples) and max(abs(x) for x in a.samples)>0.0001, name
        print(name,len(a.samples),a.sample_rate,flush=True)
if __name__=='__main__':
    if len(sys.argv)==2: check(sys.argv[1]);sys.exit(0)
    assert {p.name for p in base.iterdir() if p.is_dir()}==set(expected)
    report={}
    for name in expected:
        print('Testing '+name,flush=True)
        try:
            p=subprocess.run([sys.executable,__file__,name],capture_output=True,text=True,timeout=180)
            report[name]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
        except subprocess.TimeoutExpired:
            report[name]={'exit_code':124,'stderr':'Timeout'}
        print(report[name],flush=True)
    pathlib.Path('voice-test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    if any(r['exit_code'] for r in report.values()):sys.exit('One or more voice tests failed; see report')

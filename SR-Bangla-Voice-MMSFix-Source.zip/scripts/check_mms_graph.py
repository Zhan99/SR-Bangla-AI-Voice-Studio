"""Reject incompatible exports before native synthesis."""
from pathlib import Path
import onnx
path=Path("app/src/main/assets/bundled/Meta MMS Bengali/model.onnx")
model=onnx.load(str(path))
onnx.checker.check_model(model)
initializers={x.name for x in model.graph.initializer}
inputs=[x.name for x in model.graph.input if x.name not in initializers]
metadata={x.key:x.value for x in model.metadata_props}
print("MMS graph inputs:",inputs, "metadata:", metadata,flush=True)
assert len(inputs)==5 and all(inputs), f"Expected five Sherpa MMS VITS inputs, got {inputs}"
assert metadata.get("model_type")=="vits", "Missing VITS metadata"
assert metadata.get("frontend")=="characters", "MMS needs character frontend"
assert int(metadata.get("sample_rate","0"))>0, "Invalid sample rate"

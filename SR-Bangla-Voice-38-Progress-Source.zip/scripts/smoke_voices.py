import pathlib, math
import sherpa_onnx
base=pathlib.Path("app/src/main/assets/bundled")
expected={"Eleven-New","Merged News","SYSPIN Female","SYSPIN Male","Meta MMS Bengali"}
assert {p.name for p in base.iterdir() if p.is_dir()} == expected
for name in sorted(expected):
    p=base/name
    config=sherpa_onnx.OfflineTtsConfig(model=sherpa_onnx.OfflineTtsModelConfig(vits=sherpa_onnx.OfflineTtsVitsModelConfig(model=str(p/"model.onnx"),tokens=str(p/"tokens.txt")),num_threads=2))
    assert config.validate(), name
    tts=sherpa_onnx.OfflineTts(config)
    a=tts.generate("বাংলাদেশ আমাদের প্রিয় মাতৃভূমি।",sid=0,speed=1.0)
    assert a.sample_rate>0 and len(a.samples)>a.sample_rate//4 and all(math.isfinite(x) for x in a.samples) and max(abs(x) for x in a.samples)>0.0001, name
    print(name, len(a.samples), a.sample_rate, flush=True)
    del tts

package sr.voice

import android.app.*
import android.os.*
import android.content.*
import android.net.Uri
import android.graphics.Color
import android.media.MediaPlayer
import android.widget.*
import android.view.View
import com.k2fsa.sherpa.onnx.*
import java.io.*
import java.util.zip.ZipInputStream
import java.text.Normalizer
import java.util.concurrent.Executors

class MainActivity : Activity() {
 private val worker = Executors.newSingleThreadExecutor()
 private lateinit var text: EditText
 private lateinit var status: TextView
 private lateinit var progress: ProgressBar
 private lateinit var voices: Spinner
 private lateinit var speed: SeekBar
 private lateinit var speaker: EditText
 private lateinit var generate: Button
 private lateinit var install: Button
 private lateinit var history: LinearLayout
 private var player: MediaPlayer? = null
 private var exportFile: File? = null
 @Volatile private var cancelled = false
 private var busy = false
 private val models get() = File(filesDir,"models").apply { mkdirs() }
 private val audio get() = File(filesDir,"audio").apply { mkdirs() }
 private fun label(s:String) = TextView(this).apply { text=s; textSize=16f; setTextColor(Color.rgb(22,55,65)); setPadding(0,12,0,8) }
 private fun button(s:String, action:()->Unit) = Button(this).apply { text=s; isAllCaps=false; setOnClickListener { action() } }
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply { orientation=1; setPadding(24,48,24,32); setBackgroundColor(0xffeef8f6.toInt()) }
  setContentView(ScrollView(this).apply { addView(root) })
  root.addView(label("SR Bangla AI Voice Studio").apply { textSize=27f })
  root.addView(label("OFFLINE • Neural voice synthesis"))
  text=EditText(this).apply { hint="বাংলা লেখা লিখুন বা পেস্ট করুন"; minLines=6; gravity=48; setText("বাংলাদেশ আমাদের প্রিয় মাতৃভূমি।") }; root.addView(text)
  voices=Spinner(this); root.addView(label("ইনস্টল করা AI মডেল")); root.addView(voices)
  root.addView(label("Speaker ID (মাল্টি-স্পিকার মডেল)")); speaker=EditText(this).apply { inputType=2; setText("0") }; root.addView(speaker)
  val speedLabel=label("গতি: 1.0x"); root.addView(speedLabel)
  speed=SeekBar(this).apply { max=100; progress=50; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(b:SeekBar,p:Int,u:Boolean){speedLabel.text="গতি: ${0.5f+p/100f}x"}; override fun onStartTrackingTouch(b:SeekBar){}; override fun onStopTrackingTouch(b:SeekBar){} }) }; root.addView(speed)
  generate=button("AI ভয়েস তৈরি করুন") { synthesize() }; root.addView(generate)
  root.addView(button("বাতিল করুন") { cancelled=true })
  progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100 }; root.addView(progress)
  status=label("প্রস্তুত"); root.addView(status)
  install=button("VITS মডেল ZIP ইনস্টল") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(Intent.CATEGORY_OPENABLE) },10) }; root.addView(install)
  root.addView(button("AI মডেল ক্যাটালগ (৩৮টি)") { catalog() })
  root.addView(label("তৈরি করা অডিও")); history=LinearLayout(this).apply { orientation=1 }; root.addView(history)
  root.addView(label("Developer: Shahriar Rahman\nSR Creation Farm"))
  root.addView(button("YouTube") { browse("https://www.youtube.com/@SRCreation-farm") }); root.addView(button("Facebook") { browse("https://fb.com/srcreation.farm") })
  refresh(); refreshHistory(); if (!File(models,"Bangla VITS").exists()) {
   setBusy(true); worker.execute { try { val d=File(models,"Bangla VITS"); d.mkdirs(); for(n in listOf("model.onnx","tokens.txt")) assets.open("default/$n").use { i->File(d,n).outputStream().use { i.copyTo(it) } }; ui { status.text="অফলাইন মডেল প্রস্তুত"; refresh() } } catch(e:Exception){File(models,"Bangla VITS").deleteRecursively(); ui { status.text="মডেল কপি ব্যর্থ: ${e.message}" }} finally {ui {setBusy(false)}} }
  }
 }
 private fun ui(f:()->Unit) { runOnUiThread { if(!isDestroyed) f() } }
 private fun setBusy(v:Boolean){ busy=v; generate.isEnabled=!v; install.isEnabled=!v }
 private fun refresh(){ voices.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,models.listFiles()?.filter{File(it,"model.onnx").isFile && File(it,"tokens.txt").isFile}?.map{it.name}?.sorted()?:emptyList<String>()) }
 private fun browse(url:String){try{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}catch(e:Exception){status.text=e.message}}
 private fun catalog(){ val entries=assets.open("catalog.txt").bufferedReader().readLines().filter{it.contains("|")}; AlertDialog.Builder(this).setTitle("মডেল ক্যাটালগ — রূপান্তর/লাইসেন্স যাচাই প্রয়োজন").setItems(entries.map{it.substringBefore('|')}.toTypedArray()){_,i-> val row=entries[i].split('|'); AlertDialog.Builder(this).setTitle(row[0]).setMessage(row[2]+"\n\nশুধু Sherpa-compatible VITS ZIP সরাসরি ইনস্টল করা যাবে।").setPositiveButton("মডেল পেজ"){_,_->browse(row[1])}.setNegativeButton("বন্ধ",null).show() }.show() }
 private fun chunks(s:String):List<String>{ val result=mutableListOf<String>(); val b=StringBuilder(); for(word in s.replace(Regex("([।!?])"),"$1 ").split(Regex("\\s+"))){if(word.isBlank())continue; if(b.length+word.length>220 && b.isNotEmpty()){result.add(b.toString().trim());b.clear()}; b.append(word).append(' '); if(word.last() in "।!?" ){result.add(b.toString().trim());b.clear()}};if(b.isNotBlank())result.add(b.toString().trim());return result }
 private fun synthesize(){ if(busy)return; val input=Normalizer.normalize(text.text.toString().trim(),Normalizer.Form.NFC); val name=voices.selectedItem?.toString(); if(input.isEmpty()||name==null){status.text="লেখা ও মডেল নির্বাচন করুন";return}; val parts=chunks(input); val rate=speed.progress/100f+0.5f; val sid=speaker.text.toString().toIntOrNull()?:0; cancelled=false; setBusy(true);progress.progress=0;status.text="মডেল লোড হচ্ছে…"
 worker.execute { var tts:OfflineTts?=null; val dest=File(audio,"Voice-${System.currentTimeMillis()}.wav"); try { val dir=File(models,name); val v=OfflineTtsVitsModelConfig(model=File(dir,"model.onnx").path,tokens=File(dir,"tokens.txt").path, dataDir=File(dir,"espeak-ng-data").takeIf{it.isDirectory}?.path?:"",lexicon=File(dir,"lexicon.txt").takeIf{it.isFile}?.path?:""); val engine=OfflineTts(assetManager=null,config=OfflineTtsConfig(model=OfflineTtsModelConfig(vits=v,numThreads=2),maxNumSentences=1)); tts=engine
 RandomAccessFile(dest,"rw").use { out->out.setLength(0);out.write(ByteArray(44));var hz=0;var bytes=0L;for((i,p) in parts.withIndex()){if(cancelled)throw InterruptedException("বাতিল");val a=engine.generate(p,sid,rate);require(a.samples.isNotEmpty()){ "খালি অডিও: অংশ ${i+1}" };if(hz==0)hz=a.sampleRate;require(hz==a.sampleRate);val data=ByteArray(a.samples.size*2);for(j in a.samples.indices){val x=(a.samples[j].coerceIn(-1f,1f)*32767).toInt();data[j*2]=x.toByte();data[j*2+1]=(x shr 8).toByte()};out.write(data);bytes+=data.size; val percent=(i+1)*100/parts.size;ui{progress.progress=percent;status.text="${percent}% • ${i+1}/${parts.size} অংশ"} };require(bytes>0 && bytes<2147483600);out.seek(0);out.writeBytes("RIFF");le(out,(bytes+36).toInt(),4);out.writeBytes("WAVEfmt ");le(out,16,4);le(out,1,2);le(out,1,2);le(out,hz,4);le(out,hz*2,4);le(out,2,2);le(out,16,2);out.writeBytes("data");le(out,bytes.toInt(),4) };ui{status.text="১০০% • অডিও তৈরি হয়েছে";refreshHistory()}
 }catch(e:Throwable){dest.delete();ui{status.text="ব্যর্থ: ${e.message}"}}finally{try{tts?.release()}finally{ui{setBusy(false)}}} }
 }
 private fun le(out:RandomAccessFile,v:Int,n:Int){repeat(n){out.write((v ushr (8*it)) and 255)}}
 private fun refreshHistory(){history.removeAllViews();audio.listFiles()?.sortedByDescending{it.name}?.forEach{f->history.addView(label(f.name));history.addView(button("▶ শুনুন") {try{player?.release();player=MediaPlayer().apply{setDataSource(f.path);prepare();start()}}catch(e:Exception){status.text=e.message}});history.addView(button("WAV সেভ করুন"){exportFile=f;startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="audio/wav";putExtra(Intent.EXTRA_TITLE,f.name)},11)});history.addView(button("ডিলিট"){player?.release();player=null;f.delete();refreshHistory()})}}
 override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK)return;val uri=data?.data?:return;if(requestCode==11){val f=exportFile?:return;try{contentResolver.openOutputStream(uri)?.use{ o->f.inputStream().use{it.copyTo(o)}};status.text="সেভ হয়েছে"}catch(e:Exception){status.text=e.message};return};if(requestCode!=10||busy)return;setBusy(true);worker.execute{val d=File(models,"Imported-${System.currentTimeMillis()}");d.mkdirs();try{var total=0L;ZipInputStream(contentResolver.openInputStream(uri)!!).use{z->while(true){val e=z.nextEntry?:break;val f=File(d,e.name);require(f.canonicalPath.startsWith(d.canonicalPath+File.separator));if(e.isDirectory)f.mkdirs() else {f.parentFile?.mkdirs();f.outputStream().use{o->val buf=ByteArray(65536);while(true){val n=z.read(buf);if(n<0)break;total+=n;require(total<1500L*1024*1024);o.write(buf,0,n)}}};z.closeEntry()}};require(File(d,"model.onnx").isFile&&File(d,"tokens.txt").isFile){"ZIP root-এ model.onnx ও tokens.txt প্রয়োজন"};ui{refresh();status.text="মডেল ইনস্টল হয়েছে (সংশ্লেষণের সময় যাচাই হবে)"}}catch(e:Exception){d.deleteRecursively();ui{status.text="ইনস্টল ব্যর্থ: ${e.message}"}}finally{ui{setBusy(false)}}}}
 override fun onDestroy(){cancelled=true;player?.release();worker.shutdown();super.onDestroy()}
}
